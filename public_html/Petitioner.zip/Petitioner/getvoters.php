<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Petitions";

$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];

$link = "link";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$rs = '';
$sql = "SELECT * FROM voters where FirstName = '" . $firstname . "' and LastName = '" . $lastname . "'";
//echo $sql;
$result = $conn->query($sql);
$count = 0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
           /*$link = 'function() {
    
    document.getElementById("SurvFirstName").innerHTML = "' .$row["FirstName"]  . '";
    document.getElementById("SurvLastName").innerHTML = "' . $row["LastName"] . '";
    document.getElementById("SurvTown").innerHTML = "'  . $row["Town"] .  '";
    document.getElementById("SurvStreetName").innerHTML = "'  . $row["StreetName"] . '";
    
    document.getElementById("survey").removeAttribute("hidden");
    window.location.href = "#survey";
    
}';*/
     $link =   '
document.getElementById(' . "'" . 'survey' . "'" . ').removeAttribute('."'".'hidden'."'" . ');
window.location.href = ' . "'" . '#survey' . "'" . ';
document.getElementById(' . "'" . 'survfirstname' . "'" . ').innerHTML =' . "'" . $row["FirstName"] . "'" . ';' . 'document.getElementById(' . "'" . 'survlastname' . "'" . ').innerHTML =' . "'" . $row["LastName"] . "'" . ';' . 'document.getElementById(' . "'" . 'survtown' . "'" . ').innerHTML =' . "'" . $row["Town"] . "'" . ';' . 'document.getElementById(' . "'" . 'survstreetname' . "'" . ').innerHTML =' . "'" . $row["StreetName"] . "'" . ';';
        
        
        
        
	       $count = $count + 1;
            $rs = $rs . "<tr> <td> " . $count . '</td> <td> <a onclick = "' . $link . '">' . $row["FirstName"] . " </a> </td> <td> " . $row["LastName"] . "</td> <td> " . $row["Town"] . "</td> <td>" . $row["StreetName"] . "</td></tr>";
    
} 
}else {
    echo "0 results";
}

echo $rs . "</table>";
$conn->close();

?>          

	
