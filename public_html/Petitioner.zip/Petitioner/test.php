<?php
$str = $_GET["pw"];
echo md5($str);
?>


kevinobrien 
kev23

