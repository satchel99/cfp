<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "campaign";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 $sql = "SELECT points FROM userinfo WHERE username = " .  "'" . $_SESSION["username"] . "'";
 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["points"];	

    }
} 
 	else {
    echo "0 results";
}


$conn->close();

?>       
