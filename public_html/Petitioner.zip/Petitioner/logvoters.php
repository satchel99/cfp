<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Petitions";

/*

 voterfirstname : firstname, voterlastname: lastname, votertown:town, voterstreetname: streetname, votersigned: signed, voterifnot: ifnotwhy, votersupportpramilla: supportpramilla, voteremail: email, volunteercomments: comments


*/

$voterfirstname = $_POST["voterfirstname"];
$voterlastname = $_POST["voterlastname"];
$votertown = $_POST["votertown"];
$voterstreetname = $_POST["voterstreetname"];
$votersigned = $_POST["votersigned"];
$voterifnot = $_POST["voterifnot"];
$votersupport = $_POST["votersupportpramilla"];
$voteremail = $_POST["voteremail"];
$callercomments = $_POST["volunteercomments"];
$callername = $_SESSION["username"];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO logvoters (VoterFirstName, VoterLastName, VoterTown, VoterStreetName, VoterSigned, VoterIfNot, VoterSupport, VoterEmail, VolunteerComments,VolunteerName)
VALUES ('". $voterfirstname ."', '". $voterlastname ."', '". $votertown ."', '". $voterstreetname ."', '". $votersigned ."' , '". $voterifnot ."' , '". $votersupport ."', '" . $voteremail . "', '" .$callercomments . "', '" . $callername . "' )";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>