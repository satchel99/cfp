
function countyChanged(form) {
   
var Delaware = '<select name="town" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"><option selected disabled>-- Select Town --</option><option value="Colchester">Colchester</option><option value="Delhi">Delhi</option><option value="Hamden">Hamden</option><option value="Kortright">Kortright</option><option value="Masonville">Masonville</option><option value="Meredith">Meredith</option><option value="Thompkons">Thompkons</option><option value="Walton">Walton</option></select>';

var Orange = '   <select name="town" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"> <option selected disabled>-- Select Town --</option> <option value="Deerpark">Deerpark</option><option value="Goshen">Goshen</option><option value="Hamptonburgh">Hamptonburgh</option><option value="Middletown">Middletown</option><option value="Minisink">Minisink</option><option value="Mount Hope”>Mount Hope</option><option value="Portjervis">Portjervis</option><option value="Tuxedo">Tuxedo</option><option value="Wallkill">Wallkill</option><option value="Warwick">Warwick</option><option value="Waywayanda">Waywayanda</option></select>';

var Sullivan = '<select name="town" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"><option selected disabled>-- Select Town --</option><option value="Bethel">Bethel</option><option value="Callicoon">Callicoon</option> <option value="Cochecton">Cochecton</option><option value="Delaware">Delaware</option><option value="Fallsburgh">Fallsburgh</option><option value="Forestburgh”>Forestburgh</option><option value="Highland">Highland</option><option value="Liberty">Liberty</option><option value="Lumberland">Lumberland</option><option value="Mamakating">Mamakating</option><option value="Neversink">Neversink</option><option value="Rockland">Rockland</option><option value="Thompson">Thompson</option><option value="Tusten">Tusten</option></select>';
    
var Ulster = '   <select name="town" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"><option selected disabled>-- Select Town --</option><option value="Denning">Denning</option><option value="Gardiner">Gardiner</option><option value="New Paltz">New Paltz</option><option value="Rosendale">Rosendale</option><option value="Shawangunk">Shawangunk</option><option value="Wawarsing">Wawarsing</option></select>';
        
    
var all = '<select name="town" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"><option selected disabled>-- Select Town --</option>                                    <option value="all">ALL TOWNS</option><option value="Bethel">Bethel</option><option value="Callicoon">Callicoon</option> <option value="Cochecton">Cochecton</option><option value="Delaware">Delaware</option><option value="Fallsburgh">Fallsburgh</option><option value="Forestburgh”>Forestburgh</option><option value="Highland">Highland</option><option value="Liberty">Liberty</option><option value="Lumberland">Lumberland</option><option value="Mamakating">Mamakating</option><option value="Neversink">Neversink</option><option value="Rockland">Rockland</option><option value="Thompson">Thompson</option><option value="Tusten">Tusten</option><option value="Denning">Denning</option><option value="Gardiner">Gardiner</option><option value="New Paltz">New Paltz</option><option value="Rosendale">Rosendale</option><option value="Shawangunk">Shawangunk</option><option value="Wawarsing">Wawarsing</option><option value="Deerpark">Deerpark</option><option value="Goshen">Goshen</option><option value="Hamptonburgh">Hamptonburgh</option><option value="Middletown">Middletown</option><option value="Minisink">Minisink</option><option value="Mount Hope”>Mount Hope</option><option value="Portjervis">Portjervis</option><option value="Tuxedo">Tuxedo</option><option value="Wallkill">Wallkill</option><option value="Warwick">Warwick</option><option value="Waywayanda">Waywayanda</option><option value="Colchester">Colchester</option><option value="Delhi">Delhi</option><option value="Hamden">Hamden</option><option value="Kortright">Kortright</option><option value="Masonville">Masonville</option><option value="Meredith">Meredith</option><option value="Thompkons">Thompkons</option><option value="Walton">Walton</option></select>';
        
var main = '<select name="towns" style = "display:block;width:30%;margin-bottom:30px;border:1px solid #e4e4e4;color:#999999;	padding:10px 18px;background:url(../images/dd-arrow.svg) 97% 50% no-repeat #fff;appearance:none;-o-appearance:none;-moz-appearance:none;-ms-appearance:none;-webkit-appearance:none;cursor:pointer;"><option selected disabled>-- Select County --</option><option value="all">ALL</option><option value="WESTBROOKVILLE">WESTBROOKVILLE</option><option value="CUDDEBACKVILLE">CUDDEBACKVILLE</option><option value="HUGUENOT">HUGUENOT</option><option value="GODEFFROY">GODEFFROY</option><option value="SPARROW BUSH">SPARROW BUSH</option><option value="PORT JERVIS">PORT JERVIS</option><option value="GOSHEN">GOSHEN</option><option value="FLORIDA">FLORIDA</option><option value="NEW HAMPTON">NEW HAMPTON</option><option value="CAMPBELL HALL">CAMPBELL HALL</option><option value="CHESTER">CHESTER</option><option value="MIDDLETOWN">MIDDLETOWN</option><option value="WESTTOWN">WESTTOWN</option><option value="MONTGOMERY">MONTGOMERY</option><option value="WASHINGTONVILLE">WASHINGTONVILLE</option><option value="ROCK TAVERN">ROCK TAVERN</option> <option value="OTISVILLE">OTISVILLE</option><option value="TUXEDO">TUXEDO</option><option value="TUXEDO PARK">TUXEDO PARK</option> <option value="SOUTHFIELDS">SOUTHFIELDS</option> <option value="PINE ISLAND">PINE ISLAND</option><option value="WARWICK">WARWICK</option><option value="GREENWOOD LAKE">GREENWOOD LAKE</option><option value="MONROE">MONROE</option> <option value="STERLING FOREST">STERLING FOREST</option> <option value="SLATE HILL">SLATE HILL</option><option value="NEW HAMPTON">NEW HAMPTON</option><option value="CIRCLEVILLE">CIRCLEVILLE</option><option value="BLOOMINGBURG">BLOOMINGBURG</option><option value="HOWELLS">HOWELLS</option> </select>';
        var selectedCounty = form.county.value;
        if (selectedCounty === "all") {
                        document.getElementById("townform").innerHTML = '';

        }
         else if (selectedCounty === "main") {
            document.getElementById("townform").innerHTML = main;
        }
        
        

        
    }
 $.ajax("getusername.php", {
        type: 'POST',
        success: function(response) {
            if (response.indexOf("Undefined index") !== -1 ) {
                    window.location.href = "login.html";
                        }
            else {
                    document.getElementById("username").innerHTML = response;
                }    
            }
    
    });
    $.ajax("getpoints.php", {
        type: 'POST',
        success: function(response) {
         document.getElementById("points").innerHTML = response;
    }
            });

    $.ajax("getname.php", {
        type: 'POST',
        success: function(response) {
         document.getElementById("votersname").innerHTML = response;
    }
            });


    
    function getNumber (form) {
    
    var selectedtown;
    if (form.county.value === 'all') {
        selectedtown = 'all';
    }
    else {
         selectedtown = form.towns.value;
    }
    if (selectedtown === "-- Select Town --"){
    alert("Please Select a Town");
    }
    else if (form.county.value === "-- Select List --") {
        alert("Please select a List")
    }
    else {
    alert(selectedtown);
    $.ajax("getnumber.php", {
        data: { town : selectedtown},
        type: 'POST',
        success: function(response) {
         document.getElementById("info").innerHTML = response;
            if (response === "") {
                alert("Everyone in this county was called!");
            }
            window.location.href = "#parttwo";
    }
    });
    }
    
    }
    
    function logcall (form) {
    var name;
    var town;
    var phone;
    var info = document.getElementById("info").innerHTML;
    var writepramilla = form.writepramilla.value;
	var email = form.email.value;
	var comments = form.comment.value;

    alert(info);
    var x = 0;
    for (x; x < info.length; x++) {
        if(info.substring(x,x+4) === "<br>") {
            name = info.substring(0,x);
            break;
        }
    }
    alert(name);
    x+=4;
    var y = x;
    for (x; x < info.length; x++) {
        if(info.substring(x,x+4) === "<br>") {
            town = info.substring(y,x);
            break;
        }
    }
    alert(town);
    x+=17;
    var z = x;
    for (x; x < info.length; x++) {
        if(info.substring(x,x+2) === '">') {
            phone = info.substring(z,x);
            break;
        }
    }
    
    alert(phone);
    //alert(phone);
    //alert(document.getElementById("info").innerHTML);
    $.ajax("logcalls.php", {
        data: { votername : name, voterphone: phone, votertown:town, voterwillwriteus: writepramilla, voteremail: email, callercomments: comments},
        type: 'POST'
    });
    document.getElementById("comment").value="";
    //document.getElementById("email").value="";
     
        $.ajax("getpoints.php", {
        type: 'POST',
        success: function(response) {
         document.getElementById("points").innerHTML = response;
    }
            });
        
    window.location.href = "#home";

    }