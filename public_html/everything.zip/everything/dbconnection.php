<?php

/* $con = mysql_connect('localhost','root','root');
mysql_select_db('studyswap');*/

// Create connection
$conn = new mysqli('localhost','f50jh9o3ngpf','Sachal#99', 'pramilla');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>